//
// Created by liang on 2017/6/26.
//

#ifndef FUNCTION1_FUNCTION1_H
#define FUNCTION1_FUNCTION1_H

int Interface ();
void question(int diff_ope);
#endif //FUNCTION1_FUNCTION1_H
